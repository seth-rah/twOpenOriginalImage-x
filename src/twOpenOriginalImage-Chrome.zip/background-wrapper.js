// ■参考
// https://github.com/furyutei/twMediaDownloader/issues/89#issuecomment-1261621380
// https://groups.google.com/a/chromium.org/g/chromium-extensions/c/lLb3EJzjw0o

try {
    importScripts('js/background.js');
}
catch (error) {
    console.log(error);
}
